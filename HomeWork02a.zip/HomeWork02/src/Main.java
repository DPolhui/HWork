public class Main {
    public static void main(String[] args) {
        System.out.println("Muller Alex, age 23, height 175");
        System.out.println("");
        System.out.println("Solov Den, age 32, height 178");
        System.out.println("");
        System.out.println("Drop Lisa, age 21, height 165");
    }
}
