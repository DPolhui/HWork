public class Main {
    public static void main(String[] args) {
        int ed = 5;
        int de = 4;
        int rf = 15;
        int df = 3;
        int edde = ed % de;
        int rfdf = rf % df;
        System.out.println(edde);
        System.out.println(rfdf);
        int a = 2;
        int b = 7;
        int c = 13;
        int d = 14;
        int ad = a % 2;
        int bd = b % 2;
        int cd = c % 2;
        int dd = d % 2;
        System.out.println(ad);
        System.out.println(bd);
        System.out.println(cd);
        System.out.println(dd);

        int g2 = 127;
        int g4 = g2 % 10;
        System.out.println(g4 + " последняя цифра даного числа");

    }
}