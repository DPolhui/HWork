public class Main {
    static final char auto = 4;
    static final char bus = 34;
    public static void main(String[] args) {

        boolean metal = false;
        byte height = 23;
        short roof = 341;
        int door = 11111;
        long sven = 14l;
        float rt = 45.3f;
        double tube = 4.567;
        char fish = bus;
        System.out.println(metal + "metal");
        System.out.println(height + "height");
        System.out.println(roof + "roof");
        System.out.println(door + "door");
        System.out.println(sven + "sven");
        System.out.println(rt + "rt");
        System.out.println(tube + "tube");
        System.out.println(fish + "fish");
        door = door * 2;
        System.out.println(door);
        rt = rt / 2;
        System.out.println(rt);
        sven = sven + 1;
        System.out.println(sven);
    }
}