public class Main {
    public static void main(String[] args) {
        int den = 23;
        int rt = 45;
        int denrt = den + rt;
        System.out.println(denrt);
        int denrtm = den - rt;
        System.out.println(denrtm);
        int denrtu = den * rt;
        System.out.println(denrtu);
        int denrtd = den / rt;
        System.out.println(denrtd);
    }
}