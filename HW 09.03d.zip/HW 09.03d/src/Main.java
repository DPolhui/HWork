public class Main {
    public static void main(String[] args) {
        int i1 = 12;
        int i2 = 13;
        long l1 = 213;
        long l2 = 214;,
        double d1 = 234;
        double d2 =3456;
        float f1 = 35567;
        float f2 = 465758;
        int der = i1 + i2;
        long fer = l1 + l2;
        long yt = i1 + l1;
        float r = i1 + f1;
        double rtr = i1 + d1;
        double f = l1 + d1;

    }
}