public class Main {
    public static void main(String[] args) {
        byte t = 127;
        System.out.println(t);
        t++;
        System.out.println(t);


    }
}