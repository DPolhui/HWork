import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Проект 1
        System.out.println("Проект 1");
        Scanner scanner = new Scanner(System.in);
        System.out.println("Пользователь вводит трехзначное число ");
        int a = scanner.nextInt();
        System.out.println("Введенное число = " + a);
        System.out.println("Первая цыфра из числа = " + a/100);
        System.out.println("Вторая цыфра из числа = " + a/10%10);
        System.out.println("Третья цыфра из числа = " + a%10);

        // Проект 2
        System.out.println("Проект 2");
        System.out.println("Компьютер генерирует три произвольных числа из диапазона от 0 до 999");
        Random random = new Random();
        int b = random.nextInt(999);
        System.out.println("Сгенерированое значение = " + b);
        Random randomc = new Random();
        int c = randomc.nextInt(999);
        System.out.println("Сгенерированое значение = " +c);
        Random randomd = new Random();
        int d = randomd.nextInt(999);
        System.out.println("Сгенерированое значение = " +d);
        int e = b + c +d;
        System.out.println("Сумма трьох сгенерированих чисел = " + e);
        int f = b*c*d;
        System.out.println("Если их умножить будет равно " + f);
    }
}