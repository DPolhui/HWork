public class Main {
    public static void main(String[] args) {
        System.out.printf(
                "%.2f ",3.222
        );
        System.out.printf(
                "%.2f ",4.333
        );
        System.out.printf(
                "%.2f",5.444
        );
    }
}